Chrome Extension to show the latest data on covid of UK
=======
![covid_report](https://user-images.githubusercontent.com/11813341/152206544-8e629f40-bf26-4623-8a75-9621183fd0b5.gif)

# Tools used #
* HTML, CSS and JavaScript
* [Bootstrap 5](https://getbootstrap.com/docs/5.0/getting-started/introduction/)


Author [Sampurna Chapagain](https://twitter.com/saam_codes)
